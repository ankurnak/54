﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = 1;
            bool found = false;

            while (!found)
            {
                found = CheckCubeSum(n);
                n++;
            }

            textBox2.Text=("Найменше натуральне число, яке представлено двома різними способами у вигляді суми кубів двох натуральних чисел: " + (n - 1).ToString());
        }

        private bool CheckCubeSum(int n)
        {
            for (int i = 1; i <= Math.Pow(n, 1.0 / 3.0); i++)
            {
                for (int j = i; j <= Math.Pow(n - i * i * i, 1.0 / 3.0); j++)
                {
                    if (n == i * i * i + j * j * j && i != j)
                    {
                        return true;
                    }
                }
            }

            return false;




        }
    }
}
