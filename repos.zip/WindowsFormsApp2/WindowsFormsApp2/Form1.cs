﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox1.Text);
            double temp1 = 2 * x - 3;
            double temp2 = 2 * x - 1;
            double temp3 = Math.Pow(x, 3);
            double temp4 = Math.Pow(temp2, 2);
            double result = temp3 * temp1 + temp4 + 5;

            textBox2.Text=($"Значення виразу для x = {x} дорівнює: {result}");
        }
    }
}
