﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(textBox1.Text);
            double y1 = double.Parse(textBox2.Text);
            double x2 = double.Parse(textBox3.Text);
            double x3 = double.Parse(textBox4.Text);
            double y3 = double.Parse(textBox5.Text);
            double x4 = double.Parse(textBox6.Text);

           
            double width1 = x2 - x1;
            double height1 = y1;
            double width2 = x4 - x3;
            double height2 = y3;


            double x5 = Math.Max(x1, x3);
            double y5 = Math.Min(y1, y3);
            double x6 = Math.Min(x2, x4);
            double y6 = 0;

            if (x5 < x6 && y5 > y6)
            {
               
                double width = x6 - x5;
                double height = y5 - y6;
                double area = width * height;
                textBox7.Text=("Прямокутники перетинаються. Площа спільної частини: " + area.ToString());
            }
            else
            {
                textBox7.Text = ("Прямокутники не перетинаються.");
            }
        }
    }
}
