﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] input = textBox1.Text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int[] arr = Array.ConvertAll(input, int.Parse);

            
            int[] evenArr = new int[(arr.Length + 1) / 2]; 
            int[] oddArr = new int[arr.Length / 2];
            int evenIndex = 0;
            int oddIndex = 0;

           
            for (int i = 0; i < arr.Length; i++)
            {
                if (i % 2 == 0) 
                {
                    evenArr[evenIndex] = arr[i];
                    evenIndex++;
                }
                else 
                {
                    oddArr[oddIndex] = arr[i];
                    oddIndex++;
                }
            }

            
            string evenStr = string.Join(" ", evenArr);
            string oddStr = string.Join(" ", oddArr);
            textBox2.Text=($"Масив з парними елементами: {evenStr}\nМасив з непарними елементами: {oddStr}");
        }
    }
    }
